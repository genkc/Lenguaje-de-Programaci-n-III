﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2
{
    public partial class Formsaludo : Form
    {
        public Formsaludo()
        {
         InitializeComponent();
        }

        private void btnsaludar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;

            if (!string.IsNullOrWhiteSpace(nombre))
            {
              MessageBox.Show("Hola " + nombre + ", ¿Qué tal va tu día?",
               "Saludo",
               MessageBoxButtons.OK,
               MessageBoxIcon.Information);
            }
            else
            {
              MessageBox.Show("Por favor ingresa tu nombre.",
               "Aviso",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }

        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
         FormMenu menu = new FormMenu("Usuario");
         menu.Show();
         this.Hide();

        }

        private void txtNombre_KeyDown(object sender, KeyEventArgs e)
        {
         if (e.KeyCode == Keys.Enter)
          {
          btnsaludar.PerformClick();
          e.SuppressKeyPress = true;
            }
        }
    }
}
