﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2
{
    public partial class Forminformacionpersonal : Form
    {public Forminformacionpersonal()
        {InitializeComponent();
        }
        private void rdNo_CheckedChanged(object sender, EventArgs e)
        {}
        private void button1_Click(object sender, EventArgs e)
        {
         FormMenu menu = new FormMenu("Usuario");
         menu.Show();
         this.Hide();
        }
        private void btnRegresar_Click(object sender, EventArgs e)
        {
         FormMenu menu = new FormMenu("Usuario");
         menu.Show();
         this.Hide();
        }
        private void txtNombre_KeyDown(object sender, KeyEventArgs e)
        {
         if (e.KeyCode == Keys.Enter)
          {
          txtApellido.Focus();
          e.SuppressKeyPress = true;
          }
        }
        private void txtApellido_KeyDown(object sender, KeyEventArgs e)
        {
         if (e.KeyCode == Keys.Enter)
          {
          txtDireccion.Focus();
          e.SuppressKeyPress = true;
          }
        }
        private void txtDireccion_KeyDown(object sender, KeyEventArgs e)
        {
         if (e.KeyCode == Keys.Enter)
          {
          txtCiudad.Focus();
          e.SuppressKeyPress = true;
          }
        }
        private void btnGuardar_Click(object sender, EventArgs e)
        {
         MessageBox.Show("Datos personales guardados correctamente.",
         "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
         }
        private void btnsave_Click(object sender, EventArgs e)
         {
         MessageBox.Show("Respuestas guardadas correctamente.",
         "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
         }
    }
}
