﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2
{
    public partial class FormMenu : Form
    {
        private string nombreUsuario;

        public FormMenu(string usuario)
        {
         InitializeComponent();
         nombreUsuario = usuario;
        }

        public FormMenu()
        {
        }

        private void btnsaludo_Click(object sender, EventArgs e)
         {
         Formsaludo saludo = new Formsaludo();
         saludo.Show();
         this.Hide();
         }


        private void btnsalir_Click(object sender, EventArgs e)
        {
         Application.Exit();

        }

        private void btndatos_Click(object sender, EventArgs e)
        {
         Forminformacionpersonal datos = new Forminformacionpersonal();
         datos.Show();
         this.Hide();

        }

        private void btnoperaciones_Click(object sender, EventArgs e)
        {
         FormOperacionesBasicas operaciones = new FormOperacionesBasicas();
         operaciones.Show();
         this.Hide();

        }
    }
}
