﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btningresar_Click(object sender, EventArgs e)
        {
                  
            string contraseñaCorrecta = "1234";

            if (txtcontrasena.Text == contraseñaCorrecta)
            {
              MessageBox.Show("¡Bienvenido al sistema académico, " + txtusuario.Text + "!",
               "Acceso concedido",
               MessageBoxButtons.OK,
               MessageBoxIcon.Information);

             FormMenu menu = new FormMenu(txtusuario.Text);
             menu.Show();
             this.Hide();
            }
            else
            {
             MessageBox.Show("Contraseña incorrecta. Intenta de nuevo.",
              "Acceso denegado",
              MessageBoxButtons.OK,
              MessageBoxIcon.Error);

             txtusuario.Clear();
             txtcontrasena.Clear();
             txtusuario.Focus();
            }

            }
          
         private void btnsalir_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void txtcontrasena_KeyDown(object sender, KeyEventArgs e)
        {
         if (e.KeyCode == Keys.Enter)
          {
          btningresar.PerformClick();
          e.SuppressKeyPress = true;
            }

        }
    }
}
