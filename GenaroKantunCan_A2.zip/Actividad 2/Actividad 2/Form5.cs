﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2
{
   public partial class FormOperacionesBasicas : Form
    {
    public FormOperacionesBasicas()
        {
            InitializeComponent();
        }
     private double[] ObtenerNumeros()
      {
      double[] numeros = new double[6];
      numeros[0] = double.Parse(txtNum1.Text);
      numeros[1] = double.Parse(txtNum2.Text);
      numeros[2] = double.Parse(txtNum3.Text);
      numeros[3] = double.Parse(txtNum4.Text);
      numeros[4] = double.Parse(txtNum5.Text);
      numeros[5] = double.Parse(txtNum6.Text);
      return numeros;
      }
     private void btnSuma_Click(object sender, EventArgs e)
      {
      double[] nums = ObtenerNumeros();
      double resultado = nums.Sum();
      txtResultado.Text = resultado.ToString();
      }
     private void btnResta_Click(object sender, EventArgs e)
      {
      double[] nums = ObtenerNumeros();
      double resultado = nums[0];
      for (int i = 1; i < nums.Length; i++)
      resultado -= nums[i];
      txtResultado.Text = resultado.ToString();
      }
     private void btnMultiplicacion_Click(object sender, EventArgs e)
      {
      double[] nums = ObtenerNumeros();
      double resultado = 1;
      foreach (double n in nums)
      resultado *= n;
      txtResultado.Text = resultado.ToString();
      }
     private void btnDivision_Click(object sender, EventArgs e)
      {
      double[] nums = ObtenerNumeros();
      double resultado = nums[0];
      for (int i = 1; i < nums.Length; i++)
       {
       if (nums[i] != 0)
       resultado /= nums[i];
       else
        {
        MessageBox.Show("No se puede dividir entre cero.");
        return;
        }
       }
      txtResultado.Text = resultado.ToString();
      }
     private void btnLimpiar_Click(object sender, EventArgs e)
      {
      txtNum1.Clear();
      txtNum2.Clear();
      txtNum3.Clear();
      txtNum4.Clear();
      txtNum5.Clear();
      txtNum6.Clear();
      txtResultado.Clear();
      }
     private void btnRegresar_Click(object sender, EventArgs e)
      {
      FormMenu menu = new FormMenu("Usuario");
      menu.Show();
      this.Hide();
      }
     private void txtNum1_KeyDown(object sender, KeyEventArgs e)
      {
      if(e.KeyCode == Keys.Enter)
       {
       txtNum2.Focus();
       e.SuppressKeyPress = true;
       }
      }
     private void txtNum2_KeyDown(object sender, KeyEventArgs e)
      {
      if (e.KeyCode == Keys.Enter)
       {
       txtNum3.Focus();
       e.SuppressKeyPress = true;
       }
      }
     private void txtNum3_KeyDown(object sender, KeyEventArgs e)
      {
      if (e.KeyCode == Keys.Enter)
       {
       txtNum4.Focus();
       e.SuppressKeyPress = true;
       }
      }
     private void txtNum4_KeyDown(object sender, KeyEventArgs e)
      {
      if (e.KeyCode == Keys.Enter)
       {
       txtNum5.Focus();
       e.SuppressKeyPress = true;
       }
      }
     private void txtNum5_KeyDown(object sender, KeyEventArgs e)
      {
      if (e.KeyCode == Keys.Enter)
       {
       txtNum6.Focus();
       e.SuppressKeyPress = true;
       }
      }
    }
}
