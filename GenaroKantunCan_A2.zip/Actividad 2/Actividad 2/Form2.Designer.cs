﻿namespace Actividad_2
{
    partial class FormMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMenu));
            this.btnsaludo = new System.Windows.Forms.Button();
            this.btndatos = new System.Windows.Forms.Button();
            this.btnoperaciones = new System.Windows.Forms.Button();
            this.btnsalir = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnsaludo
            // 
            this.btnsaludo.BackColor = System.Drawing.Color.Green;
            this.btnsaludo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsaludo.FlatAppearance.BorderSize = 0;
            this.btnsaludo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsaludo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsaludo.ForeColor = System.Drawing.Color.White;
            this.btnsaludo.Location = new System.Drawing.Point(16, 398);
            this.btnsaludo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnsaludo.Name = "btnsaludo";
            this.btnsaludo.Size = new System.Drawing.Size(81, 38);
            this.btnsaludo.TabIndex = 0;
            this.btnsaludo.Text = "Saludo";
            this.btnsaludo.UseVisualStyleBackColor = false;
            this.btnsaludo.Click += new System.EventHandler(this.btnsaludo_Click);
            // 
            // btndatos
            // 
            this.btndatos.BackColor = System.Drawing.Color.RoyalBlue;
            this.btndatos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndatos.FlatAppearance.BorderSize = 0;
            this.btndatos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndatos.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndatos.ForeColor = System.Drawing.Color.White;
            this.btndatos.Location = new System.Drawing.Point(107, 398);
            this.btndatos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btndatos.Name = "btndatos";
            this.btndatos.Size = new System.Drawing.Size(163, 38);
            this.btndatos.TabIndex = 1;
            this.btndatos.Text = "Datos Personales";
            this.btndatos.UseVisualStyleBackColor = false;
            this.btndatos.Click += new System.EventHandler(this.btndatos_Click);
            // 
            // btnoperaciones
            // 
            this.btnoperaciones.BackColor = System.Drawing.Color.Orange;
            this.btnoperaciones.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnoperaciones.FlatAppearance.BorderSize = 0;
            this.btnoperaciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnoperaciones.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnoperaciones.ForeColor = System.Drawing.Color.Black;
            this.btnoperaciones.Location = new System.Drawing.Point(277, 398);
            this.btnoperaciones.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnoperaciones.Name = "btnoperaciones";
            this.btnoperaciones.Size = new System.Drawing.Size(191, 38);
            this.btnoperaciones.TabIndex = 2;
            this.btnoperaciones.Text = "Operaciones Básicas";
            this.btnoperaciones.UseVisualStyleBackColor = false;
            this.btnoperaciones.Click += new System.EventHandler(this.btnoperaciones_Click);
            // 
            // btnsalir
            // 
            this.btnsalir.BackColor = System.Drawing.Color.Red;
            this.btnsalir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsalir.FlatAppearance.BorderSize = 0;
            this.btnsalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsalir.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsalir.ForeColor = System.Drawing.Color.White;
            this.btnsalir.Location = new System.Drawing.Point(477, 398);
            this.btnsalir.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(76, 38);
            this.btnsalir.TabIndex = 3;
            this.btnsalir.Text = "Salir";
            this.btnsalir.UseVisualStyleBackColor = false;
            this.btnsalir.Click += new System.EventHandler(this.btnsalir_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Actividad_2.Properties.Resources.pngtree_a_cartoon_boy_wearing_glasses_and_hoodie_is_coding_on_his_image_16938203;
            this.pictureBox1.Location = new System.Drawing.Point(3, 5);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(567, 385);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(569, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnsalir);
            this.Controls.Add(this.btnoperaciones);
            this.Controls.Add(this.btndatos);
            this.Controls.Add(this.btnsaludo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MENÚ";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnsaludo;
        private System.Windows.Forms.Button btndatos;
        private System.Windows.Forms.Button btnoperaciones;
        private System.Windows.Forms.Button btnsalir;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}