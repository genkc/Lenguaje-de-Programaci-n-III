CREATE DATABASE Actividad3_CRUD;

CREATE TABLE CLIENTES (
    DNI INT PRIMARY KEY IDENTITY(1,1),
    Nombre_Cliente VARCHAR(50),
    Apellido_Paterno VARCHAR(50),
    Apelledo_Materno VARCHAR(50),
    Fecha_Nacimiento DATE,
    Teléfono_Cliente VARCHAR(10)
);

CREATE TABLE PROVEEDORES (
    NIF INT PRIMARY KEY IDENTITY(1,1),
    Nombre_Proveedor VARCHAR(50),
    Dirección_Proveedor VARCHAR(100),
    Teléfono_Proveedor VARCHAR(10)
);

CREATE TABLE PRODUCTOS (
    Código_Producto INT PRIMARY KEY IDENTITY(1,1),
    Nombre_Producto VARCHAR(50),
    Precio DECIMAL(10,2),
    NIF_Proveedor INT,
    Nombre_Proveedor VARCHAR(50)
    FOREIGN KEY (NIF_Proveedor) REFERENCES PROVEEDORES(NIF)
);

CREATE TABLE COMPRAS (
    ID_Compra INT PRIMARY KEY IDENTITY(1,1),
    Fecha_Compra DATE,
    DNI_Cliente INT,
    Nombre_Cliente VARCHAR(50),
    Código_Producto INT,
    Nombre_Producto VARCHAR(50),
    FOREIGN KEY (DNI_Cliente) REFERENCES CLIENTES(DNI),
    FOREIGN KEY (Código_Producto) REFERENCES PRODUCTOS(Código_Producto)
);

INSERT INTO CLIENTES (Nombre_Cliente, Apellido_Paterno, Apelledo_Materno, Fecha_Nacimiento, Teléfono_Cliente)
VALUES ('Juan', 'Pérez', 'López', '1990-05-12', '9821234567'), 
('María', 'García', 'Hernández', '1985-08-23', '9822345678'), 
('Carlos', 'Ramírez', 'Martínez', '1992-11-30', '9823456789'), 
('Ana', 'Fernández', 'Gómez', '1995-02-14', '9824567890'), 
('Luis', 'Torres', 'Sánchez', '1988-07-07', '9825678901'),
('Sofía', 'Morales', 'Castro', '1993-09-19', '9826789012'),
('Pedro', 'Vargas', 'Ruiz', '1991-12-25', '9827890123'), 
('Laura', 'Jiménez', 'Ortiz', '1987-03-05', '9828901234'), 
('Miguel', 'Domínguez', 'Silva', '1994-06-10', '9829012345'), 
('Isabel', 'Navarro', 'Flores', '1996-01-22', '9820123456'), 
('José', 'Cruz', 'Mendoza', '1989-04-18', '9821122334'), 
('Patricia', 'Reyes', 'Aguilar', '1992-10-09', '9822233445'), 
('Ricardo', 'Luna', 'Campos', '1990-12-01', '9823344556'), 
('Elena', 'Mendoza', 'Ríos', '1995-07-15', '9824455667'), 
('Andrés', 'Salazar', 'Pineda', '1986-09-27', '9825566778'); 

INSERT INTO PROVEEDORES (Nombre_Proveedor, Dirección_Proveedor, Teléfono_Proveedor)
VALUES
('Calzado Maya', 'Av. Central #123, Champotón, Campeche', '9811234567'),
('Zapatería Azteca', 'Calle Hidalgo #45, Mérida, Yucatán', '9992345678'),
('Distribuidora Yucatán', 'Blvd. Costero #67, Ciudad del Carmen, Campeche', '9383456789'),
('Moda del Sur', 'Calle Juárez #89, Villahermosa, Tabasco', '9934567890'),
('Zapatería UMI', 'Calle Principal #10, Champotón, Campeche', '9815678901');

INSERT INTO PRODUCTOS (Nombre_Producto, Precio, NIF_Proveedor, Nombre_Proveedor)
VALUES
('Zapato Formal Negro', 899.99, 1, 'Calzado Maya'),
('Tenis Deportivo Blanco', 749.50, 1, 'Calzado Maya'),
('Sandalia Dama Dorada', 499.00, 2, 'Zapatería Azteca'),
('Botín Caballero Café', 1199.00, 2, 'Zapatería Azteca'),
('Zapato Escolar Niño', 399.99, 3, 'Distribuidora Yucatán'),
('Tacón Rojo Elegante', 950.00, 3, 'Distribuidora Yucatán'),
('Mocasín Caballero Azul', 850.00, 4, 'Moda del Sur'),
('Sandalia Playera', 299.00, 4, 'Moda del Sur'),
('Tenis Running Pro', 1350.00, 5, 'Zapatería UMI'),
('Zapato Casual Beige', 620.00, 5, 'Zapatería UMI');

INSERT INTO COMPRAS (Fecha_Compra, DNI_Cliente, Nombre_Cliente, Código_Producto, Nombre_Producto)
VALUES('2026-02-21', 1, 'Juan Pérez López', 1, 'Zapato Formal Negro'),
('2026-02-15', 2, 'María García Hernández', 2, 'Tenis Deportivo Blanco'),
('2026-03-25', 3, 'Carlos Ramírez Martínez', 3, 'Sandalia Dama Dorada'),
('2026-03-24', 4, 'Ana Fernández Gómez', 4, 'Botín Caballero Café'),
('2026-03-01', 5, 'Luis Torres Sánchez', 5, 'Zapato Escolar Niño'),
('2026-03-15', 6, 'Sofía Morales Castro', 6, 'Tacón Rojo Elegante'),
('2026-03-11', 7, 'Pedro Vargas Ruiz', 7, 'Mocasín Caballero Azul'),
('2026-03-15', 8, 'Laura Jiménez Ortiz', 8, 'Sandalia Playera'),
('2026-03-21', 9, 'Miguel Domínguez Silva', 9, 'Tenis Running Pro'),
('2026-03-05', 10, 'Isabel Navarro Flores', 10, 'Zapato Casual Beige');


